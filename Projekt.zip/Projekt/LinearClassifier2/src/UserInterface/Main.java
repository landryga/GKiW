package UserInterface;

public class Main {

	public static void main(String[] args) {
		UserInterfaceImpl intf = new UserInterfaceImpl();
		//intf = null;
	}
}
